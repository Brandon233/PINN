This directory and the files contained within it were used to create the sciencebase data release https://www.sciencebase.gov/catalog/item/5d88ea50e4b0c4f70d0ab3c0
http://dx.doi.org/10.5066/P9AQPIVD

In order to run these builds, it is necessary to have access to files that were created from other computing environments. We are sharing the corresponding code to 
make it clear how the release files were assembled and posted to sciencebase with appropriate metadata. 
